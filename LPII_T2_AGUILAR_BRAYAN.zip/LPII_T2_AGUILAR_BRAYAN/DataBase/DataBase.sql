CREATE DATABASE IF NOT EXISTS bd_202336496;
USE bd_202336496;

CREATE TABLE tb_area (
    area_id INT AUTO_INCREMENT PRIMARY KEY,
    nombre_area VARCHAR(45) NOT NULL
);

CREATE TABLE tb_empleado (
    dni_empleado CHAR(8) PRIMARY KEY,
    nombre_empleado VARCHAR(45) NOT NULL,
    apellido_empleado VARCHAR(45) NOT NULL,
    fecha_nacimiento DATE NOT NULL,
    direccion VARCHAR(45),
    correo VARCHAR(45),
    area_id INT,
    FOREIGN KEY (area_id) REFERENCES tb_area(area_id)
);

INSERT INTO tb_area (nombre_area) VALUES ('Recursos Humanos');
INSERT INTO tb_area (nombre_area) VALUES ('Ventas');
INSERT INTO tb_area (nombre_area) VALUES ('Contabilidad');
INSERT INTO tb_area (nombre_area) VALUES ('Desarrollo TI');

INSERT INTO tb_empleado (dni_empleado, nombre_empleado, apellido_empleado, fecha_nacimiento, direccion, correo, area_id) 
VALUES ('12345678', 'Juan', 'Pérez', '1990-01-15', 'Av. Siempre Viva 123', 'juan.perez@mail.com', 1);

INSERT INTO tb_empleado (dni_empleado, nombre_empleado, apellido_empleado, fecha_nacimiento, direccion, correo, area_id) 
VALUES ('87654321', 'María', 'López', '1985-05-20', 'Calle Falsa 456', 'maria.lopez@mail.com', 2);

INSERT INTO tb_empleado (dni_empleado, nombre_empleado, apellido_empleado, fecha_nacimiento, direccion, correo, area_id) 
VALUES ('56781234', 'Carlos', 'García', '1992-07-10', 'Jr. Las Flores 789', 'carlos.garcia@mail.com', 3);

INSERT INTO tb_empleado (dni_empleado, nombre_empleado, apellido_empleado, fecha_nacimiento, direccion, correo, area_id) 
VALUES ('43218765', 'Ana', 'Fernández', '1993-12-25', 'Av. Los Rosales 987', 'ana.fernandez@mail.com', 4);

SELECT * FROM tb_area;
SELECT * FROM tb_empleado;