package com.examen.interfaces;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.examen.model.Area;
@Repository
public interface IAreaRepository extends JpaRepository<Area, Integer>{
	
}
