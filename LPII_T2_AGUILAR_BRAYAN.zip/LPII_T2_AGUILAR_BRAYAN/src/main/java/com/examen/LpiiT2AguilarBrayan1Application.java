package com.examen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LpiiT2AguilarBrayan1Application {

	public static void main(String[] args) {
		SpringApplication.run(LpiiT2AguilarBrayan1Application.class, args);
	}

}
