package com.examen.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "tb_empleado")
public class Empleado {
	@Id
	private String dni_empleado;
    private String nombre_empleado;
    private String apellido_empleado;
    @Column(name = "fecha_nacimiento", nullable = false)
    private LocalDate fecha_nacimiento;
    private String direccion;
    private String correo;

    @ManyToOne
    @JoinColumn(name = "area_id")
    private Area area_id;
}
