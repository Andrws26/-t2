package com.examen.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.examen.interfaces.IAreaRepository;
import com.examen.interfaces.IEmpleadoRepository;
import com.examen.model.Empleado;
@Controller
public class EmpleadoController {
	
	@Autowired
	private IAreaRepository repoArea;
	
	@Autowired
	private IEmpleadoRepository repoEmp;
	
	
	@GetMapping("/cargarCrud")
	public String cargarCrudRegistrar(Model model) {
		model.addAttribute("empleado", new Empleado());
		
		model.addAttribute("lstArea", repoArea.findAll());
		return "crudRegistrar";
	}
		
	@PostMapping("/grabar")
	public String grabarCrudRegistro(@ModelAttribute Empleado empleado) {
		return "crudRegistrar";
	}
}
