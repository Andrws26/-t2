package com.examen.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.examen.model.Empleado;

@Controller
public class CrudController {
	
	@GetMapping("/cargar")
	public String cargarCrud() {
		System.out.println("Mensaje en la consola");
		return "crudRegistrar";
	}
	@PostMapping("/cargar")
	public String leerLista() {
		return "crudRegistrar";
	}
		
}
