package com.examen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LpiiT2AguilarBrayan1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
